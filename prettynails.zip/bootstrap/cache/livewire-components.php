<?php return array (
  'admin.service-index' => 'App\\Http\\Livewire\\Admin\\ServiceIndex',
  'admin.users-index' => 'App\\Http\\Livewire\\Admin\\UsersIndex',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);