<footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12">
                        <div class="wow shake" data-wow-delay="0.4s">
                            <div class="page-scroll marginbot-30">
                                <a
                                    href="#intro"
                                    id="totop"
                                    class="btn btn-circle"
                                >
                                    <i
                                        class="fa fa-angle-double-up animated"
                                    ></i>
                                </a>
                               <br>
                                <ul class="company-social" style="text-align: center">
                                    <li class="social-instagram"><a href="https://www.instagram.com/prettynailsmg/" target="_blank"><i class="fa fa-instagram fa-3x"></i></a></li>
                                   
                                </ul>	
                          
                               
                            </div>
                        </div>
                        <p>
                            &copy;Copyright 2020 - Pretty nails & Co. Todos los derechos reservados.
                        </p>
                    </div>
                </div>
            </div>
        </footer>