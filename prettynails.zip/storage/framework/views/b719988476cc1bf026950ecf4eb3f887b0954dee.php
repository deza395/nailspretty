
<div class="form-group">
    <?php echo Form::label('name','Nombre',); ?>

    <?php echo Form::text('name',null,['class'=>'form-control', 'placeholder'=>'ingrese nombre del servicio']); ?>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger" > <?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </div>

   
   <div class="form-group">
    <?php echo Form::label('slug','Slug',); ?>

    <?php echo Form::text('slug',null,['class'=>'form-control', 'placeholder'=>'slug','readonly']); ?>

    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
       <small class="text-danger" > <?php echo e($message); ?></small>
     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </div> 



   <div class="form-group">
       <?php echo Form::label('category_id','categoria'); ?>

       <?php echo Form::select('category_id',$categories,null,['class'=>'form-control']); ?>    
       <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
         <small class="text-danger" > <?php echo e($message); ?></small>
       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </div>

   
   
   <div class="row mb-3">
    <div class="col">
      <div class="image-wrapper">
       <?php if(isset($service->image)): ?> 
       <img src="<?php echo e(Storage::url($service->image->url)); ?>" alt="" id="picture" >    
       <?php else: ?>
       <img id='picture' src="https://cdn.pixabay.com/photo/2015/02/13/14/39/painting-fingernails-635261_960_720.jpg" alt="">           
     
       <?php endif; ?>
        </div> 
    </div>
    <div class="col">
      <div class="form-group">
        <?php echo Form::label('file','imagen que se mostrara en el servicio'); ?>

        <?php echo Form::file('file',['class'=>'form-control-file','accept'=>'image/*']); ?>

        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger" > <?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
     
     <p>Ponga una imagen relacionada con el servicio por favor.</p>
    </div>
  </div>

 
   
   <div class="form-group">
    <?php echo Form::label('body','contenido'); ?>

    <?php echo Form::textarea('body',null,['class'=>'form-control']); ?>  
    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger" > <?php echo e($message); ?></small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </div>


   <div class="form-group">
       <p class="font-weight-bold">Estado</p>
       <label >
            <?php echo Form::radio('status',1,true); ?>  
            Borrador
       </label>
       <label >
            <?php echo Form::radio('status',2); ?>  
            Publicado
       </label>
       <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger" > <?php echo e($message); ?></small>
       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   </div>

<?php /**PATH C:\xampp\htdocs\prettynails\resources\views/admin/services/partials/form.blade.php ENDPATH**/ ?>