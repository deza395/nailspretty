
<?php $__env->startSection("content"); ?>
<style>
    .intro{
    background: url(../img/portada/photo.jpg) no-repeat center;
    background-size: cover;
}
    
    
</style>

<section id="intro" class="intro">
	
    <div class="slogan">
        <h2> Contáctanos<span class="text_color"></span> </h2>
        <h4>belleza de manos y piel.</h4>
    </div>
    <div class="page-scroll">
        <a href="#service" class="btn btn-circle">
            <i class="fa fa-angle-double-down animated"></i>
        </a>
    </div>
</section>


	<!-- Section: contact -->
    <section id="contact" class="home-section text-center">
		<div class="heading-contact">
			<div class="container">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wow bounceInDown" data-wow-delay="0.4s">
					<div class="section-heading">
					<h2>Dejanos tu Mensaje o Consulta</h2>
					<i class="fa fa-2x fa-angle-down"></i>

					</div>
					</div>
				</div>
			</div>
			</div>
		</div>
		<div class="container">

		<div class="row">
			<div class="col-lg-2 col-lg-offset-5">
				<hr class="marginbot-50">
			</div>
		</div>
    <div class="row">
        <div class="col-lg-8">
            <div class="boxed-grey">
                <form id="contact-form">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">
                                Nombre</label>
                            <input type="text" class="form-control" id="name" placeholder="Enter name" required="required" />
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="email">
                                Email </label>
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span>
                                </span>
                                <input type="email" class="form-control" id="email" placeholder="Enter email" required="required" /></div>
                        </div>
                    
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">
                                Mensaje</label>
                            <textarea name="message" id="message" class="form-control" rows="9" cols="25" required="required"
                                placeholder="Message"></textarea>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-skin pull-right" id="btnContactUs">
                            Enviar Mensaje</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
		
		<div class="col-lg-4">
			<div class="widget-contact">
				<br>
				
				<address style="font-size: 18px">
				  <strong>Dirección.</strong><br>
				  Las Heras 114 Monte Grande<br>
			
				  <abbr title="Phone">Tel:</abbr> +54 9 11 6541-8115
				</address>

				<address>
				  <strong>Email</strong><br>
				  <a href="mailto:#">prettynailsmg@gmail.com</a>
				</address>	
				<address>
							
			
			</div>	
		</div>
    </div>	

		</div>
	</section>
	<!-- /Section: contact -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prettynails\resources\views/front/contacto.blade.php ENDPATH**/ ?>