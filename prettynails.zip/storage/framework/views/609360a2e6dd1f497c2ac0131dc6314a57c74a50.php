

<?php $__env->startSection('title', 'Servicios'); ?>

<?php $__env->startSection('content_header'); ?>
<a href="<?php echo e(route('admin.services.create')); ?>" class="btn btn-secondary btn-sm float-right"> Nuevo servicio</a>
    <h1>Lista de Servicios</h1>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.service-index')->html();
} elseif ($_instance->childHasBeenRendered('rUykV71')) {
    $componentId = $_instance->getRenderedChildComponentId('rUykV71');
    $componentTag = $_instance->getRenderedChildComponentTagName('rUykV71');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rUykV71');
} else {
    $response = \Livewire\Livewire::mount('admin.service-index');
    $html = $response->html();
    $_instance->logRenderedChild('rUykV71', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prettynails\resources\views/admin/services/index.blade.php ENDPATH**/ ?>