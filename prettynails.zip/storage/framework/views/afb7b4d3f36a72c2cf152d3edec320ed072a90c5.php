<div class="card">

    <div class="card-header">
        <input wire:model="search" type="text" class="form-control" placeholder="ingrese el nombre del servicio">
    </div>
<?php if($services->count()): ?>
<div class="card-body">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th></th>
            </tr>     
        </thead>
        <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($service->id); ?></td>
                <td><?php echo e($service->name); ?></td>
                <td width="10px"><a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.services.edit',$service)); ?>"> Editar</a></td>
                <td  width="10px" >
                    <form action="<?php echo e(route('admin.services.destroy',$service)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="'btn btn-danger btn-sm" > eliminar</button>
                    </form>
                </td>
            </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
</div>

<div class="card-footer">
<?php echo e($services->links()); ?>

</div>
    
<?php else: ?>
<div class="card-body">
    <strong> No hay ningun registro</strong>
</div>
   
<?php endif; ?>
        
    
</div>
<?php /**PATH C:\xampp\htdocs\prettynails\resources\views/livewire/admin/service-index.blade.php ENDPATH**/ ?>